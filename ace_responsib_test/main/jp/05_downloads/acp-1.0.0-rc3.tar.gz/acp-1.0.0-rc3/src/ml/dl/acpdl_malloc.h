/*
 * ACP Middle Layer: Data Library malloc header
 * 
 * Copyright (c) 2014-2014 FUJITSU LIMITED
 * Copyright (c) 2014      Kyushu University
 * Copyright (c) 2014      Institute of Systems, Information Technologies
 *                         and Nanotechnologies 2014
 *
 * This software is released under the BSD License, see LICENSE.
 *
 * Note:
 *
 */
#ifndef __ACPDL_MALLOC_H__
#define __ACPDL_MALLOC_H__

void iacpdl_init_malloc(void);
void iacpdl_finalize_malloc(void);

#endif /* acpdl_malloc.h */
